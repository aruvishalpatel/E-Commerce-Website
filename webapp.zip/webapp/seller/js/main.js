
function validate()
{
	
		  var name = document.getElementById("name").value;
		  var number = document.getElementById("number").value;
		  var email = document.getElementById("email").value;
		  var password = document.getElementById("password").value;
		  var adhar = document.getElementById("adhar").value;
		  var pan = document.getElementById("pan").value;
		  var gstin = document.getElementById("gstin").value;
		  var accountnumber = document.getElementById("accountnumber").value;
		  var ifsc = document.getElementById("ifsc").value;
		  var address = document.getElementById("address").value;
		  
		  var numpattern = "[1-9]{1}[0-9]{2}-[0-9]{4}-[0-9]{3}";
		  
		  if (name.length > 3   &&  name.length < 50 ) 
		  {
			  $("#signupsubmit").removeAttr("disabled");
		  }
		  else 
		  {
			  $("#signupsubmit").prop("disabled","true");
			  
		 }
		  
		
}
//------------------
function submitFormLogout() 
{
	
	
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/Logout",

		
		success : function(data) {
			location.reload();

		},
		error : function(e) {
			location.reload();

		}
	});
}

//----------------------
function submitForm() 
{
	var name = document.getElementById("name").value;
	  var number = document.getElementById("number").value;
	  var email = document.getElementById("email").value;
	  var password = document.getElementById("password").value;
	  var adhar = document.getElementById("adhar").value;
	  var pan = document.getElementById("pan").value;
	  var gstin = document.getElementById("gstin").value;
	  var accountnumber = document.getElementById("accountnumber").value;
	  var ifsc = document.getElementById("ifsc").value;
	  var address = document.getElementById("address").value;
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: true,
	     url : "/multi-vendor/SellerSignUp",

		data : {
			name : name,
			number : number,
			email : email,
			password : password,
			adhar : adhar,
			pan : pan,
			gstin : gstin,
			accountnumber: accountnumber,
			ifsc : ifsc,
			address : address
			
		},
		success : function(data) {
			var output = JSON.parse(data);
			if (output.status === "success") {
				
				var x = jQuery("<div></div>").addClass("alert alert-success").append("<strong>Signup</strong> Successfull");
				$('#flash_success').html(x);
			} else {
				var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
				$('#flash_success').html(x);
			}
		},
		error : function(e) {
			
			var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
			$('#flash_success').html(x);
		}
	});
}


function validate1()
{
	
		
		  var email = document.getElementById("email").value;
		  var password = document.getElementById("password").value;
		  
		 
		  
		
}

function submitForm1() 
{
	
	var email = document.getElementById("email").value;
	var password = document.getElementById("password").value;
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/SellerLogin",

		data : {
			
			email : email,
			password : password
		},
		success : function(data) {
			
			
			
			var output = JSON.parse(data);
			location.reload();
			if (output.status === "success") {
				
				var x = jQuery("<div></div>").addClass("alert alert-success").append("<strong>Signup</strong> Successfull");
				$('#flash_success').html(x);
			} else {
				var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
				$('#flash_success').html(x);
			}
		},
		error : function(e) {
			location.reload();
			var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
			$('#flash_success').html(x);
		}
	});
}

/* price range */

$('#sl2').slider();

var RGBChange = function() {
	$('#RGB').css(
			'background',
			'rgb(' + r.getValue() + ',' + g.getValue() + ',' + b.getValue()
					+ ')')
};

/* scroll to top */

$(document).ready(function() {
	$(function() {
		$.scrollUp({
			scrollName : 'scrollUp', // Element ID
			scrollDistance : 300, // Distance from top/bottom before showing
			// element (px)
			scrollFrom : 'top', // 'top' or 'bottom'
			scrollSpeed : 300, // Speed back to top (ms)
			easingType : 'linear', // Scroll to top easing (see
			// http://easings.net/)
			animation : 'fade', // Fade, slide, none
			animationSpeed : 200, // Animation in speed (ms)
			scrollTrigger : false, // Set a custom triggering element. Can be
			// an HTML string or jQuery object
			// scrollTarget: false, // Set a custom target element for scrolling
			// to the top
			scrollText : '<i class="fa fa-angle-up"></i>', // Text for element,
			// can contain HTML
			scrollTitle : false, // Set a custom <a> title if required.
			scrollImg : false, // Set true to use image
			activeOverlay : false, // Set CSS color to display scrollUp active
		// point, e.g '#00FFFF' 		zIndex : 2147483647
		// Z-Index for the overlay
		});
	});
});

function loadProduct()
{
	$("#ProductTable").empty();
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: false,
	     url : "/multi-vendor/GetProductList",
		 success : function(data) 
		 {
			
			var table=jQuery("<table></table>").addClass("table");
			
			var theading=jQuery("<tr></tr>").append("<th>Product ID</th><th>Product Name</th><th>Product Warrenty</th><th>Product Prize</th><th>Product Quantity</th><th>Product Category</th><th> Discription</th>");
			table.append(theading);
			for (var d in data)
				{
				
				var tr=jQuery("<tr></tr>");
				var td1=jQuery("<td></td>").append(data[d].product_id);
				var td2=jQuery("<td></td>").append(data[d].product_name);
				var td3=jQuery("<td></td>").append(data[d].product_warrenty);
				var td4=jQuery("<td></td>").append(data[d].product_prize);
				var td5=jQuery("<td></td>").append(data[d].product_qty);
				var td6=jQuery("<td></td>").append(data[d].product_cat);
				var td7=jQuery("<td></td>").append(data[d].discription);
				var td8=jQuery("<td></td>");
				
				var button = jQuery("<a href='imageUpload.jsp'></a>").addClass("btn btn-success").html("Upload Photo");
				 
				 td8.append(button);
				
				
				tr.append(td1).append(td2).append(td3).append(td4).append(td5).append(td6).append(td7).append(td8);
				table.append(tr);
				}
				
			$("#ProductTable").append(table);
		 },
		error : function(e) 
		{
			var x = jQuery("<p></p>").addClass("text-danger").append("error in form");
			$('#flash_success').html(x);
		}
	});
}


function submitForm2() 
{
	var productname = document.getElementById("productname").value;
	  var productcat = document.getElementById("productcat").value;
	  var quantity = document.getElementById("quantity").value;
	  var warrenty = document.getElementById("warrenty").value;
	  var prize = document.getElementById("prize").value;
	  var disctiption = document.getElementById("disctiption").value;
	  
	jQuery.ajax({
		 type : "POST",
		 dataType: "json",
		 async: true,
	     url : "/multi-vendor/ProductAdding",

		data : {
			productname : productname,
			productcat : productcat,
			quantity : quantity,
			warrenty : warrenty,
			prize : prize,
			disctiption : disctiption,
			
			
		},
		success : function(data) {
			var output = JSON.parse(data);
			if (output.status === "success") {
				
				var x = jQuery("<div></div>").addClass("alert alert-success").append("<strong>Signup</strong> Successfull");
				$('#flash_success').html(x);
			} else {
				var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
				$('#flash_success').html(x);
			}
		},
		error : function(e) {
			
			var x = jQuery("<div></div>").addClass("alert alert-danger").append("Error in <strong>Signup</strong> ");
			$('#flash_success').html(x);
		}
	});
}


